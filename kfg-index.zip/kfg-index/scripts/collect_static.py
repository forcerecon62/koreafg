"""
서버(나스/도커) 없이 GitHub Actions에서 매일 실행되는 스크립트.

동작 방식:
  1. docs/data/history.json (지금까지의 일별 기록 배열)을 읽는다.
  2. backend/app/collectors의 수집기들을 그대로 재사용해 오늘자 raw 지표값을 가져온다.
  3. 과거 기록에서 지표별 raw값 분포를 뽑아 percentile로 0~100 점수를 매긴다
     (backend/app/scoring.py와 동일한 로직이지만, DB 대신 JSON 배열을 사용하도록
     가볍게 재구현했다 - 이 스크립트는 SQLAlchemy 등 서버 의존성이 전혀 없다).
  4. 오늘자 기록을 추가해 docs/data/history.json에 다시 쓴다.
     (이후 GitHub Actions 워크플로가 이 파일을 저장소에 커밋한다.)

docs/index.html이 이 JSON 파일을 fetch해서 대시보드를 그린다 - 별도 API 서버가 필요 없다.
"""
import sys
import os
import json
from bisect import bisect_left
from pathlib import Path
from datetime import date

# backend/app 패키지(설정+수집기)를 재사용하기 위해 경로 추가.
# collectors 모듈들은 DB에 의존하지 않으므로(app.config만 사용) 그대로 가져다 쓸 수 있다.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "backend"))
from app import config  # noqa: E402
from app.collectors import (  # noqa: E402
    market_index, fx, safe_haven, breadth, foreign_flow, strength,
)

COLLECTORS = [market_index, fx, safe_haven, breadth, foreign_flow, strength]

REPO_ROOT = Path(__file__).resolve().parent.parent
DATA_PATH = REPO_ROOT / "docs" / "data" / "history.json"

MAX_RECORDS = 800  # 대략 3년치 거래일. 파일 크기를 무한정 키우지 않기 위한 상한.


def percentile_score(value: float, history: list) -> float:
    if not history:
        return 50.0
    s = sorted(history)
    idx = bisect_left(s, value)
    return round(idx / len(s) * 100, 1)


def label_for(score: float) -> str:
    if score < 25:
        return "극단적 공포"
    if score < 45:
        return "공포"
    if score <= 55:
        return "중립"
    if score <= 75:
        return "탐욕"
    return "극단적 탐욕"


def load_history() -> list:
    if DATA_PATH.exists():
        try:
            return json.loads(DATA_PATH.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            print("[WARN] 기존 history.json 파싱 실패 - 빈 배열로 시작합니다")
    return []


def save_history(records: list):
    DATA_PATH.parent.mkdir(parents=True, exist_ok=True)
    DATA_PATH.write_text(
        json.dumps(records, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def collect_all_raw() -> dict:
    raw = {}
    for mod in COLLECTORS:
        try:
            raw.update(mod.collect())
        except Exception as e:
            print(f"[WARN] {mod.__name__} 전체 실패: {e}")
    return raw


def main():
    today = date.today().isoformat()
    history = load_history()
    # 같은 날 재실행(수동 재시도 등) 시 중복 없이 덮어쓰기 위해 오늘자 기존 기록 제거
    history = [r for r in history if r["date"] != today]

    raw = collect_all_raw()
    if not raw:
        print("[ERROR] 모든 지표 수집 실패 - 이번 실행은 기록하지 않고 종료합니다")
        sys.exit(1)

    print("수집된 raw 지표:", raw)

    # 지표별 과거 raw값 분포 구성 (최근 LOOKBACK_DAYS개 기록에서 추출)
    per_indicator_hist = {k: [] for k in raw}
    for rec in history[-config.LOOKBACK_DAYS:]:
        for c in rec.get("components", []):
            if c["key"] in per_indicator_hist:
                per_indicator_hist[c["key"]].append(c["raw"])

    components = []
    scores = {}
    for key, value in raw.items():
        hist = per_indicator_hist.get(key, []) + [value]
        pct = percentile_score(value, hist)
        greedy_high = config.INDICATOR_DIRECTION_GREEDY_WHEN_HIGH.get(key, True)
        score = pct if greedy_high else round(100 - pct, 1)
        scores[key] = score
        components.append({
            "key": key,
            "label": config.INDICATOR_LABELS.get(key, key),
            "raw": value,
            "score": score,
            "verdict": label_for(score),
        })

    total_w, acc = 0.0, 0.0
    for k, w in config.INDICATOR_WEIGHTS.items():
        if k in scores:
            acc += scores[k] * w
            total_w += w
    composite = round(acc / total_w, 1) if total_w else 50.0

    record = {
        "date": today,
        "composite_score": composite,
        "verdict": label_for(composite),
        "components": components,
    }
    history.append(record)
    history.sort(key=lambda r: r["date"])
    history = history[-MAX_RECORDS:]

    save_history(history)
    print(f"✅ {today} 저장 완료 - 합성지수 {composite}점 ({label_for(composite)})")


if __name__ == "__main__":
    main()
