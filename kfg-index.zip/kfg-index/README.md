# K-FGI · 한국 공포 & 탐욕 지수

코스피/코스닥 시장 심리를 0~100 점수로 종합하는 자체 지수 대시보드입니다.
스크린샷의 `yasun.gg`와 같은 컨셉을 직접 운용할 수 있도록 수집 → 점수화 → 저장 → API → 대시보드까지 전체를 구현했습니다.

## 구조

```
kfg-index/
├── backend/
│   ├── app/
│   │   ├── config.py          # 지표 가중치, 티커, 스케줄 설정
│   │   ├── db.py / models.py  # SQLite 저장소 (나스/서버용)
│   │   ├── scoring.py         # raw값 -> 0~100 percentile 점수 변환 (나스/서버용)
│   │   ├── collect_and_score.py  # 일일 배치 오케스트레이터 (나스/서버용)
│   │   ├── main.py            # FastAPI - 대시보드 API + 정적 파일 서빙 (나스/서버용)
│   │   └── collectors/        # 지표별 데이터 수집 모듈 (두 방식 공용)
│   ├── scheduler.py           # 매일 17:05 KST 자동 실행 (나스/서버용)
│   ├── requirements.txt       # 나스/서버 배포용 전체 의존성
│   └── requirements-static.txt   # GitHub Actions용 경량 의존성
├── frontend/
│   └── index.html             # 나스/서버용 대시보드 (FastAPI API를 fetch)
├── scripts/
│   └── collect_static.py      # GitHub Actions용 수집+점수화 스크립트 (DB 불필요)
├── docs/
│   ├── index.html             # GitHub Pages용 대시보드 (정적 JSON을 fetch)
│   └── data/history.json      # 매일 GitHub Actions가 갱신·커밋하는 데이터
├── .github/workflows/daily.yml   # 매일 17:05 KST 자동 실행 (GitHub Actions용)
└── docker-compose.yml
```

두 가지 운영 방식 중 하나만 골라 써도 되고, 그대로 둘 다 저장소에 넣어두고 필요할 때 골라 써도 됩니다.

## 8개 구성 지표

| 지표 | 소스 | 의미 |
|---|---|---|
| KOSPI/KOSDAQ 모멘텀 | Yahoo Finance | 20일 이평 대비 괴리율 |
| 변동성 (KOSPI) | Yahoo Finance | 20일 실현변동성(연율화) |
| 환율 스트레스 | Yahoo Finance | 원/달러 5일 변동률 |
| 시장 폭 (KS-KQ) | KRX (pykrx) | 상승-하락 종목 비율 |
| 외국인 5일 수급 | KRX (pykrx) | 외국인 5일 순매수 대금 |
| 주가 강도 (52주) | KRX (pykrx) | 시총 상위 100종목 중 52주 신고가/신저가 근접 비율 |
| 안전자산 수요 | Yahoo Finance | KOSPI 20일 수익률 - 금 20일 수익률 스프레드 |

각 지표는 **최근 1년(252거래일) 분포 내 백분위**로 0~100점 환산되고, `config.py`의 가중치로 가중 평균되어
최종 지수가 됩니다. CNN Fear & Greed Index와 동일한 percentile 방식입니다.

> ⚠️ 처음 운영을 시작하면 히스토리가 없어 며칠간은 지표가 50점(중립) 근처로 나올 수 있습니다.
> 데이터가 쌓일수록(약 1~2개월) percentile이 정교해집니다.

## 📱 지금 폰만으로 배포하기 (나스/PC 불필요)

나스에 접속할 수 없는 상황(여행 중 등)이라면 **서버 없이 GitHub Actions + GitHub Pages**로 완전히
무료 운영할 수 있습니다. 매일 계산은 GitHub의 서버가 대신 해주고, 결과는 정적 웹페이지로
호스팅됩니다. 전부 휴대폰 브라우저에서 가능합니다.

1. **GitHub 계정 준비**: [github.com](https://github.com) 접속 → 계정 없으면 가입.

2. **새 저장소 생성**: 우측 상단 `+` → `New repository` → 이름 예: `kfg-index` →
   **Public**으로 설정(Pages 무료 사용 조건) → `Create repository`.

3. **이 zip 파일 업로드**: 저장소 페이지에서 `Add file` → `Upload files`.
   휴대폰 파일 앱에서 이 zip을 먼저 압축 해제한 뒤, 그 안의 파일/폴더 전체를 선택해서
   업로드하세요(iOS/Android 기본 파일 앱 모두 압축 해제 지원). 업로드 후 하단의
   `Commit changes`를 눌러 저장합니다.

4. **GitHub Pages 켜기**: 저장소의 `Settings` → 왼쪽 메뉴 `Pages` →
   `Source: Deploy from a branch` → `Branch: main`, 폴더: `/docs` → `Save`.
   1분 정도 후 `https://<계정명>.github.io/kfg-index/` 로 대시보드가 열립니다.

5. **워크플로 권한 확인**: `Settings` → `Actions` → `General` → 아래쪽
   `Workflow permissions`에서 `Read and write permissions` 선택 → `Save`.
   (매일 계산 결과를 저장소에 자동 커밋하려면 필요합니다.)

6. **첫 데이터 채우기**: 상단 `Actions` 탭 → 왼쪽 `Daily K-FGI Update` 선택 →
   오른쪽 `Run workflow` 버튼 → `Run workflow`. 1~2분 후 새로고침하면
   `docs/data/history.json`에 오늘자 데이터가 커밋된 것을 볼 수 있고,
   대시보드에도 반영됩니다.

7. 이후에는 평일 매일 17:05(KST)에 자동으로 실행됩니다. 필요하면 언제든 6번처럼
   `Run workflow`로 수동 실행할 수 있습니다.

> 나중에 나스에 다시 접속할 수 있게 되면, 같은 저장소의 `backend/` + `docker-compose.yml`로
> 아래 "시놀로지 NAS 배포" 절차를 그대로 따라 하면 됩니다. 두 방식은 완전히 독립적으로
> 공존하므로 굳이 지금 것을 버릴 필요가 없습니다.

## 로컬에서 먼저 테스트하기 (나스/서버로 운영할 경우)

```bash
cd kfg-index
docker compose build
docker compose up -d

# 배치를 수동으로 1회 즉시 실행해서 오늘자 데이터를 채워봅니다
docker compose exec scheduler python scheduler.py --now

# 브라우저에서 확인
http://localhost:8000
```

pykrx는 KRX 서버에서 스크래핑하는 방식이라 요청이 느릴 수 있고(특히 `주가 강도` 지표는 100종목을 순회하므로
1~2분 소요될 수 있음), 장 시작 전/공휴일에는 일부 지표가 비어 있을 수 있습니다(자동으로 건너뛰고 나머지로 계산).

## 시놀로지 NAS 배포 (Container Manager)

1. **파일 업로드**: File Station에서 공유폴더(예: `docker`)에 `kfg-index` 폴더 전체를 업로드합니다.
   (SSH가 활성화되어 있다면 `git clone`이나 `scp`로 옮기는 것이 더 편합니다.)

2. **데이터 저장 경로 지정 (선택)**: `docker-compose.yml`의 volumes를 익명 볼륨 대신
   실제 경로로 바꾸면 DSM에서 파일을 직접 볼 수 있어 백업하기 편합니다.
   ```yaml
   volumes:
     - /volume1/docker/kfg-index/data:/data
   ```
   (두 서비스 모두 동일하게 수정)

3. **Container Manager 실행**
   - Container Manager 열기 → 프로젝트 → 생성
   - 프로젝트 이름: `kfg-index`
   - 경로: 업로드한 `kfg-index` 폴더 선택 (docker-compose.yml 자동 인식)
   - 빌드 후 실행

4. **접속 확인**: NAS IP:8000 (예: `http://192.168.0.10:8000`)으로 접속되면 성공.

5. **외부 도메인 연결 (선택)**
   - DSM 제어판 → 로그인 포털 → 고급 → 역방향 프록시에서
     `yourdomain.com` → `localhost:8000`으로 규칙 추가
   - Let's Encrypt 인증서는 제어판 → 보안 → 인증서에서 발급/연결

6. **자동 시작**: `restart: unless-stopped`가 설정되어 있어 NAS 재부팅 시에도 자동으로 다시 시작됩니다.

## 커스터마이즈

- **가중치 조정**: `backend/app/config.py`의 `INDICATOR_WEIGHTS`
- **새 지표 추가**: `backend/app/collectors/`에 `collect() -> {"my_indicator": raw_value}`를 반환하는
  모듈을 추가하고, `config.py`의 `INDICATOR_WEIGHTS`/`INDICATOR_LABELS`/`INDICATOR_DIRECTION_GREEDY_WHEN_HIGH`,
  `collect_and_score.py`의 `COLLECTORS` 리스트, `models.py`의 컬럼에 반영
- **갱신 시각 변경**: `config.py`의 `DAILY_RUN_HOUR` / `DAILY_RUN_MINUTE`

## 알아두면 좋은 점

- **pykrx는 비공식 라이브러리**입니다(KRX 정보데이터시스템을 스크래핑). KRX가 페이지 구조를 바꾸면
  일부 지표 수집이 깨질 수 있습니다 — 이 경우 `docker compose logs scheduler`로 어떤 지표가 실패했는지 확인하세요.
  실패한 지표는 자동으로 제외되고 나머지 지표만으로 지수가 계산되므로 서비스 자체가 죽지는 않습니다.
- 데이터는 SQLite(WAL 모드)로 저장되어 API 컨테이너와 스케줄러 컨테이너가 동시에 접근해도 안전합니다.
- 참고/개인용 지표이며 투자 조언이 아닙니다.
