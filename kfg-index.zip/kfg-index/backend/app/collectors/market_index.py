"""
KOSPI / KOSDAQ 지수 시세로부터 모멘텀, 변동성 raw 지표를 계산한다.
데이터 소스: Yahoo Finance (yfinance) - 별도 API 키 불필요, 무료.
"""
import logging
import numpy as np
import yfinance as yf

from .. import config

log = logging.getLogger(__name__)

MOMENTUM_MA_DAYS = 20   # 20거래일 이동평균 대비 괴리율
VOL_WINDOW_DAYS = 20    # 20거래일 실현변동성(연율화)


def _fetch_ohlc(ticker: str, period: str = "1y"):
    df = yf.download(ticker, period=period, interval="1d", progress=False, auto_adjust=True)
    if df is None or df.empty:
        raise RuntimeError(f"{ticker} 데이터를 가져오지 못했습니다")
    return df


def get_momentum(ticker: str) -> float:
    """(마지막 종가 - N일 이동평균) / N일 이동평균 * 100"""
    df = _fetch_ohlc(ticker)
    close = df["Close"].dropna()
    ma = close.rolling(MOMENTUM_MA_DAYS).mean()
    last_close = float(close.iloc[-1])
    last_ma = float(ma.iloc[-1])
    return round((last_close - last_ma) / last_ma * 100, 2)


def get_realized_volatility(ticker: str) -> float:
    """일간 로그수익률의 N일 표준편차를 연율화(%)"""
    df = _fetch_ohlc(ticker)
    close = df["Close"].dropna()
    log_ret = np.log(close / close.shift(1)).dropna()
    recent = log_ret.tail(VOL_WINDOW_DAYS)
    ann_vol = float(recent.std() * np.sqrt(252) * 100)
    return round(ann_vol, 2)


def collect() -> dict:
    """kospi_momentum, kosdaq_momentum, volatility raw값을 한번에 반환"""
    out = {}
    try:
        out["kospi_momentum"] = get_momentum(config.YF_KOSPI)
    except Exception as e:
        log.warning("kospi_momentum 수집 실패: %s", e)

    try:
        out["kosdaq_momentum"] = get_momentum(config.YF_KOSDAQ)
    except Exception as e:
        log.warning("kosdaq_momentum 수집 실패: %s", e)

    try:
        out["volatility"] = get_realized_volatility(config.YF_KOSPI)
    except Exception as e:
        log.warning("volatility 수집 실패: %s", e)

    return out
