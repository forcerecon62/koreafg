from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from .. import config


def now_kst() -> datetime:
    return datetime.now(ZoneInfo(config.TIMEZONE))


def today_str(fmt: str = "%Y%m%d") -> str:
    return now_kst().strftime(fmt)


def days_ago_str(n: int, fmt: str = "%Y%m%d") -> str:
    return (now_kst() - timedelta(days=n)).strftime(fmt)
