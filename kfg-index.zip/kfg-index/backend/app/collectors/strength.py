"""
주가 강도 (52주): 시가총액 상위 N개 종목을 표본으로, 52주 고가 대비 -5% 이내(신고가권) 종목 수에서
52주 저가 대비 +5% 이내(신저가권) 종목 수를 뺀 값의 비율(%).
전종목을 매일 순회하면 NAS에 부담이 크므로 대형주 표본으로 근사한다 (표본 크기는 config에서 조정 가능).
값이 낮을수록(신저가권 종목 우세) 공포.
데이터 소스: pykrx
"""
import logging
from pykrx import stock

from .. import config
from .util import today_str, days_ago_str

log = logging.getLogger(__name__)

TOP_N_BY_CAP = 100
NEAR_BAND_PCT = 5.0  # 52주 고/저가 대비 ±5% 이내를 "근접"으로 판정
LOOKBACK_DAYS_52W = 365


def _top_tickers(date: str, n: int) -> list:
    df = stock.get_market_cap_by_ticker(date, market="ALL", alternative=True)
    df = df.sort_values("시가총액", ascending=False)
    return list(df.index[:n])


def collect() -> dict:
    out = {}
    try:
        date = today_str()
        fromdate = days_ago_str(LOOKBACK_DAYS_52W)
        tickers = _top_tickers(date, TOP_N_BY_CAP)

        near_high, near_low, counted = 0, 0, 0
        for ticker in tickers:
            try:
                ohlcv = stock.get_market_ohlcv_by_date(fromdate, date, ticker)
                if ohlcv.empty:
                    continue
                high_52w = float(ohlcv["고가"].max())
                low_52w = float(ohlcv["저가"].min())
                last_close = float(ohlcv["종가"].iloc[-1])

                if high_52w > 0 and (high_52w - last_close) / high_52w * 100 <= NEAR_BAND_PCT:
                    near_high += 1
                if low_52w > 0 and (last_close - low_52w) / low_52w * 100 <= NEAR_BAND_PCT:
                    near_low += 1
                counted += 1
            except Exception:
                continue

        if counted == 0:
            raise RuntimeError("표본 종목 시세를 하나도 가져오지 못했습니다")

        strength = (near_high - near_low) / counted * 100
        out["price_strength"] = round(strength, 2)
    except Exception as e:
        log.warning("price_strength 수집 실패: %s", e)
    return out
