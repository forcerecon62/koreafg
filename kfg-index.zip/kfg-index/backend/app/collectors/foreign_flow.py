"""
외국인 5일 수급: 최근 5거래일간 외국인 투자자의 코스피+코스닥 전체 순매수 대금 합계 (억원).
값이 클수록(순매수 우세) 탐욕.
데이터 소스: pykrx
"""
import logging
from pykrx import stock

from .util import today_str, days_ago_str

log = logging.getLogger(__name__)

WINDOW_DAYS = 7  # 주말 포함 여유있게 7일 범위로 조회 -> 실제로는 최근 5거래일이 잡힘


def collect() -> dict:
    out = {}
    try:
        fromdate = days_ago_str(WINDOW_DAYS)
        todate = today_str()
        df = stock.get_market_net_purchases_of_equities(
            fromdate, todate, market="ALL", investor="외국인"
        )
        total_krw = float(df["순매수거래대금"].sum())
        total_eok = round(total_krw / 100_000_000, 1)  # 원 -> 억원
        out["foreign_flow"] = total_eok
    except Exception as e:
        log.warning("foreign_flow 수집 실패: %s", e)
    return out
