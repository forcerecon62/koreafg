"""
시장 폭 (Market Breadth): 코스피+코스닥 전종목 중 상승 종목 수 - 하락 종목 수, 전체 대비 %.
값이 낮을수록(하락종목 우세) 공포.
데이터 소스: pykrx (KRX 정보데이터시스템 비공식 래퍼)
"""
import logging
from pykrx import stock

from .util import today_str

log = logging.getLogger(__name__)


def collect() -> dict:
    out = {}
    try:
        date = today_str()
        df = stock.get_market_ohlcv_by_ticker(date, market="ALL", alternative=True)
        chg = df["등락률"]
        advancers = int((chg > 0).sum())
        decliners = int((chg < 0).sum())
        total = advancers + decliners
        if total == 0:
            raise RuntimeError("등락 데이터가 비어 있습니다")
        breadth = (advancers - decliners) / total * 100
        out["market_breadth"] = round(breadth, 2)
    except Exception as e:
        log.warning("market_breadth 수집 실패: %s", e)
    return out
