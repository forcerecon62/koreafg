"""
안전자산 수요: KOSPI 20일 수익률 - 금(Gold) 20일 수익률 스프레드.
스프레드가 낮을수록(주식이 금 대비 부진) 안전자산 쏠림 = 공포.
"""
import logging
import yfinance as yf

from .. import config

log = logging.getLogger(__name__)

RETURN_WINDOW_DAYS = 20


def _n_day_return(ticker: str, window: int) -> float:
    df = yf.download(ticker, period="1y", interval="1d", progress=False, auto_adjust=True)
    close = df["Close"].dropna()
    last = float(close.iloc[-1])
    prior = float(close.iloc[-1 - window])
    return (last - prior) / prior * 100


def collect() -> dict:
    out = {}
    try:
        kospi_ret = _n_day_return(config.YF_KOSPI, RETURN_WINDOW_DAYS)
        gold_ret = _n_day_return(config.YF_GOLD, RETURN_WINDOW_DAYS)
        out["safe_haven"] = round(kospi_ret - gold_ret, 2)
    except Exception as e:
        log.warning("safe_haven 수집 실패: %s", e)
    return out
