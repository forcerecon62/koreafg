"""
원/달러 환율 스트레스: 최근 5거래일 변동률(%).
값이 클수록(원화 약세 심화) 시장 심리는 공포 쪽으로 기운다.
"""
import logging
import yfinance as yf

from .. import config

log = logging.getLogger(__name__)

CHANGE_WINDOW_DAYS = 5


def collect() -> dict:
    out = {}
    try:
        df = yf.download(config.YF_USDKRW, period="6mo", interval="1d", progress=False, auto_adjust=True)
        close = df["Close"].dropna()
        last = float(close.iloc[-1])
        prior = float(close.iloc[-1 - CHANGE_WINDOW_DAYS])
        pct_change = round((last - prior) / prior * 100, 2)
        out["fx_stress"] = pct_change
    except Exception as e:
        log.warning("fx_stress 수집 실패: %s", e)
    return out
