"""
한국 공포&탐욕 지수 - 전역 설정
지표를 추가/제거하거나 가중치를 바꾸고 싶으면 이 파일만 수정하면 됩니다.
"""
import os

# ── 저장소 ────────────────────────────────────────────────
DATA_DIR = os.environ.get("KFG_DATA_DIR", "/data")
DB_PATH = os.path.join(DATA_DIR, "kfg_index.sqlite3")
DATABASE_URL = f"sqlite:///{DB_PATH}"

# ── 지수 계산 ─────────────────────────────────────────────
# 각 지표의 percentile(0~100)을 구할 때 참고하는 과거 구간(거래일 기준)
LOOKBACK_DAYS = 252  # 약 1년

# 최종 지수 = 아래 지표들의 가중 평균 (가중치 합 = 1.0)
INDICATOR_WEIGHTS = {
    "kospi_momentum": 0.15,
    "kosdaq_momentum": 0.10,
    "volatility": 0.15,
    "fx_stress": 0.15,
    "market_breadth": 0.15,
    "foreign_flow": 0.10,
    "price_strength": 0.10,
    "safe_haven": 0.10,
}

INDICATOR_LABELS = {
    "kospi_momentum": "KOSPI 모멘텀",
    "kosdaq_momentum": "KOSDAQ 모멘텀",
    "volatility": "변동성 (KOSPI)",
    "fx_stress": "환율 스트레스",
    "market_breadth": "시장 폭 (KS-KQ)",
    "foreign_flow": "외국인 5일 수급",
    "price_strength": "주가 강도 (52주)",
    "safe_haven": "안전자산 수요",
}

# 지표별 방향: True면 raw값이 클수록 탐욕(점수↑), False면 raw값이 클수록 공포(점수↓ = 반전)
INDICATOR_DIRECTION_GREEDY_WHEN_HIGH = {
    "kospi_momentum": True,
    "kosdaq_momentum": True,
    "volatility": False,      # 변동성 급등 = 공포
    "fx_stress": False,       # 원화 약세/환율 급변 = 공포
    "market_breadth": True,
    "foreign_flow": True,
    "price_strength": True,
    # safe_haven raw = (KOSPI 수익률 - 금 수익률) 스프레드.
    # 값이 낮을수록(주식이 금 대비 부진 = 안전자산 쏠림) 공포이므로 greedy_when_high=True로 두고
    # raw 자체가 이미 "낮으면 공포" 방향을 갖도록 설계한다.
    "safe_haven": True,
}

# ── 티커 ──────────────────────────────────────────────────
YF_KOSPI = "^KS11"
YF_KOSDAQ = "^KQ11"
YF_USDKRW = "KRW=X"
YF_GOLD = "GC=F"

TIMEZONE = "Asia/Seoul"
DAILY_RUN_HOUR = 17
DAILY_RUN_MINUTE = 5
