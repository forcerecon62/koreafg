from sqlalchemy import Column, Integer, String, Float, Date, UniqueConstraint
from .db import Base


class IndicatorRaw(Base):
    """지표별 원시값 (percentile 계산의 기초 데이터, 무기한 누적)"""
    __tablename__ = "indicator_raw"

    id = Column(Integer, primary_key=True, autoincrement=True)
    date = Column(Date, nullable=False, index=True)
    indicator = Column(String(64), nullable=False, index=True)
    raw_value = Column(Float, nullable=False)

    __table_args__ = (
        UniqueConstraint("date", "indicator", name="uq_date_indicator"),
    )


class IndexScore(Base):
    """일자별 최종 지수 및 지표별 0~100 점수 스냅샷"""
    __tablename__ = "index_score"

    id = Column(Integer, primary_key=True, autoincrement=True)
    date = Column(Date, nullable=False, unique=True, index=True)
    composite_score = Column(Float, nullable=False)

    # 지표별 0~100 점수 (스냅샷 시점 기준, 카드 표시용)
    kospi_momentum = Column(Float)
    kosdaq_momentum = Column(Float)
    volatility = Column(Float)
    fx_stress = Column(Float)
    market_breadth = Column(Float)
    foreign_flow = Column(Float)
    price_strength = Column(Float)
    safe_haven = Column(Float)

    # 지표별 raw value (카드의 "raw: xx" 표시용)
    kospi_momentum_raw = Column(Float)
    kosdaq_momentum_raw = Column(Float)
    volatility_raw = Column(Float)
    fx_stress_raw = Column(Float)
    market_breadth_raw = Column(Float)
    foreign_flow_raw = Column(Float)
    price_strength_raw = Column(Float)
    safe_haven_raw = Column(Float)
