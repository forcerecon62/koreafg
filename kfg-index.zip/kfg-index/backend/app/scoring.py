"""
raw 지표값 -> 0~100 점수 변환 (percentile rank 방식, CNN Fear&Greed와 동일한 접근)

방법:
  1. 최근 LOOKBACK_DAYS 거래일 동안 쌓인 해당 지표의 raw 값 분포를 가져온다.
  2. 오늘 raw 값이 그 분포에서 몇 번째 백분위인지 계산 -> 0~100
  3. 지표 방향이 "낮을수록 탐욕"인 경우 100에서 뺀다 (반전).
  4. 지표별 가중치로 가중 평균 -> 최종 합성 지수 (0=극단적 공포, 100=극단적 탐욕)
"""
from bisect import bisect_left
from datetime import date
from typing import Dict, List

from sqlalchemy import select

from . import config
from .models import IndicatorRaw


def percentile_score(value: float, history: List[float]) -> float:
    """history(과거 raw값 리스트, 오늘 값 포함 가능) 안에서 value의 백분위(0~100)."""
    if not history:
        return 50.0
    s = sorted(history)
    idx = bisect_left(s, value)
    pct = idx / len(s) * 100
    return round(pct, 1)


def get_history(session, indicator: str, before: date, limit_days: int) -> List[float]:
    rows = (
        session.execute(
            select(IndicatorRaw.raw_value)
            .where(IndicatorRaw.indicator == indicator, IndicatorRaw.date < before)
            .order_by(IndicatorRaw.date.desc())
            .limit(limit_days)
        )
        .scalars()
        .all()
    )
    return list(rows)


def score_indicator(session, indicator: str, raw_value: float, as_of: date) -> float:
    history = get_history(session, indicator, as_of, config.LOOKBACK_DAYS)
    history.append(raw_value)
    pct = percentile_score(raw_value, history)
    greedy_when_high = config.INDICATOR_DIRECTION_GREEDY_WHEN_HIGH.get(indicator, True)
    return pct if greedy_when_high else round(100 - pct, 1)


def compute_composite(scores: Dict[str, float]) -> float:
    total_w = 0.0
    acc = 0.0
    for k, w in config.INDICATOR_WEIGHTS.items():
        if k in scores and scores[k] is not None:
            acc += scores[k] * w
            total_w += w
    if total_w == 0:
        return 50.0
    return round(acc / total_w, 1)


def label_for(score: float) -> str:
    if score < 25:
        return "극단적 공포"
    if score < 45:
        return "공포"
    if score <= 55:
        return "중립"
    if score <= 75:
        return "탐욕"
    return "극단적 탐욕"
