import os
from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker, declarative_base

from . import config

os.makedirs(config.DATA_DIR, exist_ok=True)

engine = create_engine(
    config.DATABASE_URL,
    connect_args={"check_same_thread": False},
)


@event.listens_for(engine, "connect")
def _set_sqlite_pragma(dbapi_connection, connection_record):
    # WAL 모드: API(읽기 프로세스)와 스케줄러(쓰기 프로세스)가 동시에 접근해도
    # "database is locked" 오류 없이 안정적으로 동작하도록 함.
    cursor = dbapi_connection.cursor()
    cursor.execute("PRAGMA journal_mode=WAL")
    cursor.execute("PRAGMA busy_timeout=5000")
    cursor.close()
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()


def init_db():
    from . import models  # noqa: ensures models are registered
    Base.metadata.create_all(bind=engine)


def get_session():
    return SessionLocal()
