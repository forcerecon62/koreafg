from datetime import date, timedelta

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import select

from . import config, scoring
from .db import get_session, init_db
from .models import IndexScore

app = FastAPI(title="한국 공포 & 탐욕 지수 API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 자체 NAS/가정용 배포 기준. 외부 공개 시 도메인으로 좁히세요.
    allow_methods=["GET"],
    allow_headers=["*"],
)


@app.on_event("startup")
def on_startup():
    init_db()


def _row_to_dict(row: IndexScore) -> dict:
    components = []
    for key, label in config.INDICATOR_LABELS.items():
        score = getattr(row, key, None)
        raw = getattr(row, f"{key}_raw", None)
        if score is None:
            continue
        components.append(
            {
                "key": key,
                "label": label,
                "score": score,
                "raw": raw,
                "verdict": scoring.label_for(score),
            }
        )
    return {
        "date": row.date.isoformat(),
        "score": row.composite_score,
        "verdict": scoring.label_for(row.composite_score),
        "components": components,
    }


@app.get("/api/latest")
def latest():
    session = get_session()
    try:
        row = session.execute(
            select(IndexScore).order_by(IndexScore.date.desc()).limit(1)
        ).scalar_one_or_none()
        if row is None:
            raise HTTPException(status_code=404, detail="아직 계산된 지수가 없습니다")
        return _row_to_dict(row)
    finally:
        session.close()


@app.get("/api/history")
def history(days: int = 120):
    session = get_session()
    try:
        since = date.today() - timedelta(days=days)
        rows = session.execute(
            select(IndexScore.date, IndexScore.composite_score)
            .where(IndexScore.date >= since)
            .order_by(IndexScore.date.asc())
        ).all()
        return [{"date": d.isoformat(), "score": s} for d, s in rows]
    finally:
        session.close()


@app.get("/api/health")
def health():
    return {"status": "ok"}


# ── 정적 프론트엔드 서빙 (있을 경우) ──────────────────────
# /api/* 라우트들이 위에서 먼저 등록되었으므로 그쪽이 우선 매칭되고,
# 그 외 모든 경로(/, /index.html 등)는 아래 StaticFiles가 처리한다.
import os
from fastapi.staticfiles import StaticFiles

_FRONTEND_DIR = os.environ.get("KFG_FRONTEND_DIR", "/srv/frontend")
if os.path.isdir(_FRONTEND_DIR):
    app.mount("/", StaticFiles(directory=_FRONTEND_DIR, html=True), name="frontend")
