"""
매일 1회 실행되는 배치 잡:
  1. 모든 collector를 호출해 raw 지표값을 모은다.
  2. raw값을 IndicatorRaw 테이블에 저장(누적 이력 = percentile 계산의 재료).
  3. 각 지표를 0~100 점수로 환산하고, 가중 평균으로 최종 합성 지수를 계산한다.
  4. 오늘자 IndexScore 스냅샷을 upsert 한다.

일부 지표 수집이 실패해도(공휴일, 외부 소스 오류 등) 나머지 지표만으로 계속 진행한다.
"""
import logging
from datetime import date

from sqlalchemy import select

from .db import get_session, init_db
from .models import IndicatorRaw, IndexScore
from . import scoring
from .collectors import market_index, fx, safe_haven, breadth, foreign_flow, strength

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)

COLLECTORS = [market_index, fx, safe_haven, breadth, foreign_flow, strength]


def collect_all_raw() -> dict:
    raw = {}
    for mod in COLLECTORS:
        try:
            raw.update(mod.collect())
        except Exception as e:
            log.error("collector %s 전체 실패: %s", mod.__name__, e)
    return raw


def run(target_date: date = None):
    init_db()
    target_date = target_date or date.today()
    session = get_session()
    try:
        raw = collect_all_raw()
        if not raw:
            log.error("모든 지표 수집에 실패했습니다. 이번 배치는 건너뜁니다.")
            return

        log.info("수집된 raw 지표: %s", raw)

        # 1) raw값 저장 (upsert)
        for indicator, value in raw.items():
            existing = session.execute(
                select(IndicatorRaw).where(
                    IndicatorRaw.date == target_date, IndicatorRaw.indicator == indicator
                )
            ).scalar_one_or_none()
            if existing:
                existing.raw_value = value
            else:
                session.add(IndicatorRaw(date=target_date, indicator=indicator, raw_value=value))
        session.commit()

        # 2) 점수화
        scores = {}
        for indicator, value in raw.items():
            scores[indicator] = scoring.score_indicator(session, indicator, value, target_date)

        composite = scoring.compute_composite(scores)
        log.info("지표별 점수: %s / 합성 지수: %s", scores, composite)

        # 3) IndexScore 스냅샷 upsert
        row = session.execute(
            select(IndexScore).where(IndexScore.date == target_date)
        ).scalar_one_or_none()
        if row is None:
            row = IndexScore(date=target_date)
            session.add(row)

        row.composite_score = composite
        for indicator in raw:
            setattr(row, indicator, scores.get(indicator))
            setattr(row, f"{indicator}_raw", raw.get(indicator))

        session.commit()
        log.info("%s 기준 지수 저장 완료: %s점", target_date, composite)
    finally:
        session.close()


if __name__ == "__main__":
    run()
