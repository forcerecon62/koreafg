"""
독립 실행 스케줄러: 매일 지정된 시각(기본 17:05 KST, KRX 정규장 마감 이후)에
app.collect_and_score.run()을 실행한다.

사용법:
  python scheduler.py            # 스케줄 대기 (매일 자동 실행)
  python scheduler.py --now      # 지금 즉시 1회 실행 후 종료 (초기 백필/테스트용)
"""
import sys
import logging
from apscheduler.schedulers.blocking import BlockingScheduler
from apscheduler.triggers.cron import CronTrigger

from app.collect_and_score import run
from app import config

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)


def main():
    if "--now" in sys.argv:
        log.info("즉시 1회 실행 모드")
        run()
        return

    scheduler = BlockingScheduler(timezone=config.TIMEZONE)
    scheduler.add_job(
        run,
        trigger=CronTrigger(
            hour=config.DAILY_RUN_HOUR,
            minute=config.DAILY_RUN_MINUTE,
            day_of_week="mon-fri",  # 평일에만 (KRX 개장일 기준, 공휴일은 collector가 알아서 skip)
            timezone=config.TIMEZONE,
        ),
        id="daily_collect_and_score",
        misfire_grace_time=3600,
    )
    log.info(
        "스케줄러 시작 - 매일 평일 %02d:%02d (%s)에 실행됩니다",
        config.DAILY_RUN_HOUR, config.DAILY_RUN_MINUTE, config.TIMEZONE,
    )
    scheduler.start()


if __name__ == "__main__":
    main()
